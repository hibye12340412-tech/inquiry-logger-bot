import discord
from discord.ext import commands
import asyncio

from config import BOT_TOKEN
from utils.database import init_db


class InquiryLoggerBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True  # 채널 로그 수집용

        super().__init__(
            command_prefix="!",
            intents=intents
        )

    async def setup_hook(self):
        # DB 초기화
        init_db()

        # Cog 로드
        await self.load_extension("cogs.inquiry")

        # 슬래시 명령어 동기화
        await self.tree.sync()
        print("✅ 슬래시 명령어 동기화 완료")

    async def on_ready(self):
        print(f"🤖 로그인 완료: {self.user} (ID: {self.user.id})")


async def main():
    bot = InquiryLoggerBot()
    await bot.start(BOT_TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
