# 디스코드 봇 토큰
BOT_TOKEN = "MTQ2NjA4NzY2MjU2ODg2OTg5MA.Gdu1FA.93Bw_bNpWK8JYspDh184GbkqnX0m_QqARKHe2s"

# 문의 로그를 저장할 채널 ID
# 예: #문의-세이브 채널 우클릭 → ID 복사
SAVE_CHANNEL_ID = 123456789012345678

# 로그에서 제외할 봇 ID (선택)
# Ticket Tool 봇 ID 등
EXCLUDED_BOT_IDS = set()
