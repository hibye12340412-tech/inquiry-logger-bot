import io
import discord
from discord.ext import commands
from discord import app_commands

from utils.log_exporter import export_channel_log
from utils.database import insert_inquiry
from config import SAVE_CHANNEL_ID, EXCLUDED_BOT_IDS


class Inquiry(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="문의기록", description="현재 티켓 채널의 문의 내용을 기록합니다.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def save_inquiry(self, interaction: discord.Interaction):
        channel = interaction.channel

        if not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message(
                "❌ 텍스트 채널에서만 사용할 수 있습니다.",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        # 로그 채널 가져오기
        save_channel = interaction.guild.get_channel(SAVE_CHANNEL_ID)
        if save_channel is None:
            await interaction.followup.send(
                "❌ 문의 세이브 채널을 찾을 수 없습니다.",
                ephemeral=True
            )
            return

        # 로그 생성
        log_text = await export_channel_log(
            channel,
            exclude_bots=False,
            exclude_bot_ids=EXCLUDED_BOT_IDS
        )

        # txt 파일 생성 (메모리)
        filename = f"inquiry_{channel.name}_{interaction.id}.txt"
        file = discord.File(
            fp=io.BytesIO(log_text.encode("utf-8")),
            filename=filename
        )

        # 로그 채널로 전송
        await save_channel.send(
            content=(
                f"📌 **문의 기록 저장됨**\n"
                f"- 서버: {interaction.guild.name}\n"
                f"- 채널: {channel.mention}\n"
                f"- 저장자: {interaction.user.mention}"
            ),
            file=file
        )

        # DB 저장
        insert_inquiry(
            guild_id=interaction.guild.id,
            channel_id=channel.id,
            saved_by=interaction.user.id,
            file_name=filename
        )

        await interaction.followup.send(
            "✅ 문의 기록이 성공적으로 저장되었습니다.",
            ephemeral=True
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(Inquiry(bot))
