import discord
from datetime import datetime


async def export_channel_log(
    channel: discord.TextChannel,
    *,
    exclude_bots: bool = False,
    exclude_bot_ids: set[int] | None = None
) -> str:
    """
    채널 메시지를 txt 문자열로 변환

    :param channel: 현재 티켓 채널
    :param exclude_bots: 모든 봇 메시지 제외
    :param exclude_bot_ids: 특정 봇 ID만 제외
    :return: txt 형태 문자열
    """

    lines: list[str] = []

    header = (
        f"서버: {channel.guild.name} ({channel.guild.id})\n"
        f"채널: #{channel.name} ({channel.id})\n"
        f"로그 생성 시각: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        "----------------------------------------\n"
    )
    lines.append(header)

    async for msg in channel.history(limit=None, oldest_first=True):
        # 봇 메시지 필터링
        if exclude_bots and msg.author.bot:
            continue

        if exclude_bot_ids and msg.author.id in exclude_bot_ids:
            continue

        timestamp = msg.created_at.strftime("%Y-%m-%d %H:%M:%S")
        author = f"{msg.author} ({msg.author.id})"
        content = msg.content or ""

        # 첨부파일 표시
        if msg.attachments:
            files = ", ".join(att.url for att in msg.attachments)
            content += f"\n[첨부파일] {files}"

        # 임베드 표시
        if msg.embeds:
            content += f"\n[임베드 {len(msg.embeds)}개 포함]"

        lines.append(f"[{timestamp}] {author}\n{content}\n")

    return "\n".join(lines)
