import sqlite3
from pathlib import Path
from datetime import datetime

# DB 경로 (프로젝트 루트/inquiry_logger_bot/db/inquiries.db)
BASE_DIR = Path(__file__).resolve().parent.parent
DB_DIR = BASE_DIR / "db"
DB_PATH = DB_DIR / "inquiries.db"


def get_connection():
    """SQLite 연결 (없으면 파일 자동 생성)"""
    DB_DIR.mkdir(exist_ok=True)
    return sqlite3.connect(DB_PATH)


def init_db():
    """테이블 자동 생성"""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS inquiries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL,
        saved_by INTEGER NOT NULL,
        saved_at TEXT NOT NULL,
        file_name TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()


def insert_inquiry(
    guild_id: int,
    channel_id: int,
    saved_by: int,
    file_name: str,
    saved_at: str | None = None
):
    """문의 기록 메타데이터 저장"""
    if saved_at is None:
        saved_at = datetime.now().isoformat(timespec="seconds")

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO inquiries (guild_id, channel_id, saved_by, saved_at, file_name)
    VALUES (?, ?, ?, ?, ?)
    """, (guild_id, channel_id, saved_by, saved_at, file_name))

    conn.commit()
    conn.close()